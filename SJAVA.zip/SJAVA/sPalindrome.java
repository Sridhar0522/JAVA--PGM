import java.util.Scanner;
public class sPalindrome 
{
	public static void main(String args[])
	{
		String strorg,rev="";
		System.out.println("Enter the String");
		Scanner S = new Scanner(System.in);
		strorg = S.nextLine();
		int length = strorg.length();
		for(int i = length-1;i>=0;i--)
		{
			rev = rev+strorg.charAt(i);
			
		}
			if(strorg.equals(rev))
			{
				System.out.println("Palindrome");
				
				
			}
			else
			{
				System.out.println("not a Palindrome");
			}
			
		
	}
}
