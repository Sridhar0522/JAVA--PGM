import java.util.Scanner;
public class Palindrome 
{
	public static void main(String[] args)
	{
		int temp,rev=0,rem;
		
		System.out.println(" Enter the Number");
		Scanner s = new Scanner(System.in);
		temp = s.nextInt();
		int c=temp;//Value should be store in other variable as it is going to do Comparison\
		while(temp!=0) 
		{
			rem = temp%10;
			rev=rev*10+rem;
			temp = temp/10;
		}
		
			if (c==rev)
			{
				System.out.println("The given number is Palindrome : "+c);
				
			}	
			else
			{
				
			 System.out.println("The given number is not an Palindrome : " +c);
		}
	
	}
}
