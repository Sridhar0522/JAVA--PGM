import java.util.Scanner;
public class swapping 
{
	public static void main(String[] args)
	{
		int x,y,z;
		System.out.println("Enter the Value of X");
		Scanner s = new Scanner(System.in);
		x= s.nextInt();
		System.out.println("Enter the value of Y");
		y= s.nextInt();
		System.out.println("The Value of X and Y Before Swapping : "+x+" "+y);
		z=x;
		x=y;
		y=z;
		System.out.println("The Value of X and Y After Swapping : "+x+" "+y);
		
	}
}
