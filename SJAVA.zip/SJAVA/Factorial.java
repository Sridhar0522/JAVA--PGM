
import java.util.Scanner;
Class Factorial
{
	Public static vaoid main(Sting[] args)
		{
 			int n=5,fact=1;
			
			

			for(int i=1; i<=5; i++)
			{
				fact=fact*i;
			}
			
		}

}
