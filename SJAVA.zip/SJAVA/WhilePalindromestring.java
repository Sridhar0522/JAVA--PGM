import java.util.Scanner;
public class WhilePalindromestring 
{
	public static void main(String args[])
	{
		String strorg,rev="";
		System.out.println("Enter the String");
		Scanner S = new Scanner(System.in);
		strorg = S.nextLine();
		//Using while loop
		int FL,LL,Flag=0;
		FL = 0;
		LL = strorg.length()-1;
		while(FL<LL&&Flag==0)
		{
			if(strorg.charAt(FL)!=strorg.charAt(LL))
				Flag =1;
			FL=FL+1;
			LL=LL-1;
			
		}
		if(Flag==0)
		{
			System.out.println("Palindrome");
		}
		else
			System.out.println("Not a Palindrome");
		
	}
}
