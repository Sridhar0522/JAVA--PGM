import java.util.Scanner;
public class Fib {
 public static void main(String[] args)
 {
	  int a=0,b=1,c;
	  System.out.print("enter the term");
	  Scanner r = new Scanner(System.in);
	  int term = r.nextInt();
	  for (int i=1;i<=term;i++)
	  {
		  
		  c=a+b;
		  a=b;
	  	  b=c;
	  	System.out.print(a+"");	
	  }
	  
	  
 }
}
