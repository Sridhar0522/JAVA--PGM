import java.util.Scanner;
class Buzz {
public static void main (String[] args)
{
	int i,n;
	
	System.out.print("Enter the Value");
	Scanner scan = new Scanner(System.in);
	n =  scan.nextInt();
	System.out.println("The FIZZ The BUZZ and FIZZBUZZ Numbers are");
	for(i=1;i<=n;i++)
	{
		if(i%3==0&&i%5==0)
			{
		System.out.println("FIZZBUZZ");
			}
		else if(i%3==0)
		{
			System.out.println("FIZZ");
			
		}
		else if(i%5==0)
		{
			System.err.println("BUZZ");
			
		}
		}
			}
	
	
			
}


